import { KinesisClient, PutRecordCommand } from '@aws-sdk/client-kinesis';
import axios from 'axios';

// Initialize the Kinesis client
const kinesis = new KinesisClient({ region: process.env.AWS_REGION });

export const handler = async (event, context) => {
    console.log('Event received:', JSON.stringify(event, null, 2));
    
    try {
        // Extract request parameters
        const requestBody = event.body ? JSON.parse(event.body) : {};
        const queryParams = event.queryStringParameters || {};
        
        // Configuration values
        const EXTERNAL_API_URL = process.env.EXTERNAL_API_URL;
        const STREAM_NAME = process.env.STREAM_NAME;
        
        if (!EXTERNAL_API_URL) {
            throw new Error('External API URL is not configured');
        }
        
        if (!STREAM_NAME) {
            throw new Error('Kinesis stream name is not configured');
        }
        
        // Call the external API
        console.log(`Calling external API: ${EXTERNAL_API_URL}`);
        const apiResponse = await callExternalApi(
            EXTERNAL_API_URL, 
            requestBody, 
            queryParams, 
            event.headers || {}
        );
        
        // Process the API response
        const processedData = processApiResponse(apiResponse, event);
        
        // Stream the processed data to Kinesis
        await streamToKinesis(processedData, STREAM_NAME);
        
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: 'Data successfully processed and sent to Kinesis',
                requestId: context.awsRequestId
            })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: error.statusCode || 500,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: `Error: ${error.message}`,
                requestId: context.awsRequestId
            })
        };
    }
};

async function callExternalApi(url, body, queryParams, headers) {
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            params: queryParams,
            headers: headers
        });
        return response.data;
    } catch (error) {
        console.error('External API error:', error);
        throw new Error(`External API request failed: ${error.message}`);
    }
}

function processApiResponse(apiResponse, originalEvent) {
    const timestamp = new Date().toISOString();
    const requestId = originalEvent.requestContext?.requestId || 'unknown';
    
    return {
        timestamp,
        requestId,
        source: 'api-gateway',
        data: apiResponse
    };
}

async function streamToKinesis(data, streamName) {
    const dataString = typeof data === 'string' ? data : JSON.stringify(data);
    
    const record = {
        StreamName: streamName,
        Data: Buffer.from(dataString),
        PartitionKey: data.requestId || String(Date.now())
    };
    
    console.log(`Sending data to Kinesis stream: ${streamName}`);
    
    try {
        const command = new PutRecordCommand(record);
        const response = await kinesis.send(command);
        console.log('Data sent to Kinesis successfully:', response);
        return response;
    } catch (error) {
        console.error('Error sending data to Kinesis:', error);
        throw new Error(`Failed to send data to Kinesis: ${error.message}`);
    }
}